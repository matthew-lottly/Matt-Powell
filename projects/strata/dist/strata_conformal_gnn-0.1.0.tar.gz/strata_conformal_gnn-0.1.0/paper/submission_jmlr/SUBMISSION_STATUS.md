# STRATA JMLR Submission Status

## Ready

- Core paper draft exists in `manuscript_draft.tex`
- `references.bib` exists
- `data_provenance.txt` exists
- CI can build a draft PDF artifact
- A submission bundle script exists: `scripts/build_submission_bundle.py`
- Reproducibility assets exist: code, tests, examples, outputs, benchmark scripts

## Still Required Before Submission

1. Switch `manuscript_draft.tex` from generic `article` formatting to the official JMLR style files (`jmlr2e.sty` / current style repo). This is currently the biggest blocker.
2. Produce and verify the final PDF, including bibliography, page count, and file size under the JMLR upload limit.
3. Complete the title page requirements: corresponding author address/email, condensed running title, exactly five keywords, and abstract under 200 words.
4. Prepare the cover letter with:
   - prior-publication disclosure (if any)
   - author-consent statement
   - conflict-of-interest disclosure
   - 3-5 suggested action editors
   - 3-5 suggested reviewers
   - article keywords
5. Check JMLR scope risk: the current framing is infrastructure-focused, so the introduction and contribution framing should continue emphasizing general ML methodology rather than only application value.
6. Build `supplementary.zip` using the bundle script and verify it contains only necessary reproducibility artifacts.
7. Verify final figures/tables are regenerated from current outputs and referenced consistently in the manuscript.
8. Decide whether to include an appendix in the manuscript or supplementary archive for extra diagnostics, fairness analysis, and ablations.

## Recommended Final Pre-Submission Sequence

1. Run `scripts/run_real_data_benchmark.py`
2. Run `scripts/run_ablations.py`
3. Run `scripts/fairness_audit.py`
4. Run `scripts/build_submission_bundle.py`
5. Compile the paper with official JMLR style files
6. Review the cover letter and submission metadata
